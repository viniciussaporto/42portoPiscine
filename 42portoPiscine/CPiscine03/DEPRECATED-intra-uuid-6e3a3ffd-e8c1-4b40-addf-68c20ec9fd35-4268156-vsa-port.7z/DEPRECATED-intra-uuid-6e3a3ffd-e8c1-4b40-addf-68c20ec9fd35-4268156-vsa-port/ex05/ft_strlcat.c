/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vsa-port <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/25 19:32:48 by vsa-port          #+#    #+#             */
/*   Updated: 2022/07/26 16:51:55 by vsa-port         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
//#include <stdio.h>
//#include <bsd/string.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	j = ft_strlen(dest);
	while (src[i] != '\0' && i < (size - j - 1))
	{
		dest[j + i] = src[i];
		i++;
	}
	dest[j + i] = '\0';
	return (j + i);
}
/*int	main(void)
{
	char	src[] = "Kiki";
	char	dest[] = "EI";
	int		test;
	int		irl;

	test = ft_strlcat(dest, src, 10);
	printf("MY FUNCTION: %d\n", test);
	strlcat(dest, src, 10);
	printf("REAL FUNCTION: %d", irl);
	return (0);
}*/
